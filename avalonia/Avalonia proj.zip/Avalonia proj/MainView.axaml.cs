using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Avalonia.Diagnostics;

namespace FrameBuffer
{
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }

/*        private void InitializeComponent()
        {
            AvaloniaXamlLoader.Load(this);
        } */
    }
}
