using ReactiveUI;
using System;
using System.Collections.Generic;
using System.Text;
using Avalonia.Collections;
using FrameBuffer.Models;

namespace FrameBuffer.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {

        private AvaloniaList<Device>? devices;
        public AvaloniaList<Device> Devices
        {
            get => devices;
            set
            {
                devices = value;
                this.RaiseAndSetIfChanged(ref devices, value);
            }
        }

        public bool ServerIsStart = false;
        public void ShownDevice(string str)
        {
            ShownDevices = str;
        }

        private string textLog2 = "";
        
        public void Log(string str)
        {
            ShownDevices = ShownDevices + str;
        }

        public string ShownDevices
        {
            get => textLog2;
            set => this.RaiseAndSetIfChanged(ref textLog2, value);
        }
    }
}
