﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReactiveUI;
using Avalonia.Collections;

namespace FrameBuffer.Models
{
    public enum Operation
    {
        ChangeState
    }

    public class GetDevice : ReactiveObject
    {
        public string? job_date { get; set; }
        public AvaloniaList<Device>? devices { get; set; }
    }
    public class Device : ReactiveObject
    {
        private string? _guid;
        private string? _index;
        private string? _state;
        private string? _ip;
        private string? _class;
        private string? _name;
        private string? _isnew;
        private string? _mac;


        public string guid
        {
            get { return _guid; }
            set { _guid = value; this.RaiseAndSetIfChanged(ref _guid, value); }
        }

        public string index
        {
            get { return _index; }
            set { _index = value; this.RaiseAndSetIfChanged(ref _index, value); }
        }

        public string state
        {
            get { return _state; }
            set { _state = value; this.RaiseAndSetIfChanged(ref _state, value); }
        }
        public string ip
        {
            get { return _ip; }
            set { _ip = value; this.RaiseAndSetIfChanged(ref _ip, value); }
        }

        public string @class
        {
            get { return _class; }
            set { _class = value; this.RaiseAndSetIfChanged(ref _class, value); }
        }
        public string name
        {
            get { return _name; }
            set { _name = value; this.RaiseAndSetIfChanged(ref _name, value); }
        }
        public string isnew
        {
            get { return _isnew; }
            set { _isnew = value; this.RaiseAndSetIfChanged(ref _isnew, value); }
        }
        public string mac
        {
            get { return _mac; }
            set { _mac = value; this.RaiseAndSetIfChanged(ref _mac, value); }
        }
    }
}
